import React from "react";
import "./Dashboard.css";
import Menu from "../adminDash/Menu/Menu";
function Dashboard() {
  return (
    <div className="dashboardCon">
      <h1>
        Welcome to Dashboard Mrs Ghribi !
      </h1>
    </div>
  );
}

export default Dashboard;
