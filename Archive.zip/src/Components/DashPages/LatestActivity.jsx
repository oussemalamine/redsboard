import React from 'react'

function LatestActivity() {
  return (
    <div>LatestActivity</div>
  )
}

export default LatestActivity