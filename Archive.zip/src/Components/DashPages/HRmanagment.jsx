import React from "react";

function HRmanagment() {
  return <div>HRmanagment</div>;
}

export default HRmanagment;
