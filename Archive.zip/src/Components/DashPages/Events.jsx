import React from "react";

function Events() {
  return <div>Events</div>;
}

export default Events;
